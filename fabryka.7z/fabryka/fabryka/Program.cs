﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fabryka
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Interface1 ob = null;

            string nameC;
            do
            {
                Console.WriteLine("Podaj nazwę klasy(users, products lub priviledges) której spis chcesz wyświetlić.");
                nameC = Console.ReadLine();
            }
            while (nameC != "products" && nameC != "users" && nameC!= "priviledges");

            Console.WriteLine("Klasa: ", nameC);

            if(nameC=="users")
            {
                try
                {
                    ob = factory.getObject("users");
                    ob.addItem("Jan Brzechwa");
                    ob.addItem("Wilhelm Karl Grimm");
                    ob.addItem("Jacob Ludwig Karl Grimm");
                    ob.addItem("Hans Christian Andersen");
                    Console.WriteLine(ob.listItems());
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Jest błąd, i coś nie działa. Przykre.");
                }
            }
            if (nameC=="products")
            {
                try
                {
                    ob = factory.getObject("products");
                    ob.addItem("Książka");
                    ob.addItem("Płyta");
                    ob.addItem("Kaseta");
                    Console.WriteLine(ob.listItems());
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Jest błąd, i coś nie działa. Przykre.");
                }
            }
            if (nameC == "priviledges")
            {
                try
                {
                    ob = factory.getObject("priviledges");
                    ob.addItem("Ciastko co dziennie");
                    ob.addItem("Mleko co dziennie");
                    ob.addItem("Kostka drogiego masła");
                    Console.WriteLine(ob.listItems());
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Jest błąd, i coś nie działa. Smuteczek.");
                }
            }
            Console.Read();
        }
    }
}