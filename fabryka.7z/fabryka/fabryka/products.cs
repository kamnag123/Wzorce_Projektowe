﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace fabryka
{
    public class products : Interface1
    {
        List<String> list;
        public products()
        {
            list = new List<string>();
        }

        string Interface1.addItem(String product)
        {
            list.Add(product);
            return "Dodano nowy produkt: " + product;
        }

        string Interface1.deleteItem(int number)
        {
            list.RemoveAt(number);
            return "Produkt o numerze: " + number + " został usunięty.";
        }

        string Interface1.listItems()
        {
            foreach (object user in list)
                Console.WriteLine("Nazwa produktu: " + user);
            return "";
        }
        string Interface1.sortItems()
        {
            return "Sortowanie zakończone ";
        }
    }
}