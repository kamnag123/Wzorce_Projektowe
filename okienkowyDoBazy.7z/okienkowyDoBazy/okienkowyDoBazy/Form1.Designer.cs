﻿namespace okienkowyDoBazy
{
    partial class Form1
    {
        /// <summary>
        /// Wymagana zmienna projektanta.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Wyczyść wszystkie używane zasoby.
        /// </summary>
        /// <param name="disposing">prawda, jeżeli zarządzane zasoby powinny zostać zlikwidowane; Fałsz w przeciwnym wypadku.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kod generowany przez Projektanta formularzy systemu Windows

        /// <summary>
        /// Metoda wymagana do obsługi projektanta — nie należy modyfikować
        /// jej zawartości w edytorze kodu.
        /// </summary>
        private void InitializeComponent()
        {
            this.dodaj = new System.Windows.Forms.Button();
            this.usun = new System.Windows.Forms.Button();
            this.sortuj = new System.Windows.Forms.Button();
            this.tabela = new System.Windows.Forms.DataGridView();
            this.dodajImie = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.dodajNazwisko = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.tabela)).BeginInit();
            this.SuspendLayout();
            // 
            // dodaj
            // 
            this.dodaj.Location = new System.Drawing.Point(691, 46);
            this.dodaj.Name = "dodaj";
            this.dodaj.Size = new System.Drawing.Size(83, 101);
            this.dodaj.TabIndex = 0;
            this.dodaj.Text = "dodaj";
            this.dodaj.UseVisualStyleBackColor = true;
            this.dodaj.Click += new System.EventHandler(this.dodaj_Click);
            // 
            // usun
            // 
            this.usun.Location = new System.Drawing.Point(691, 180);
            this.usun.Name = "usun";
            this.usun.Size = new System.Drawing.Size(83, 109);
            this.usun.TabIndex = 1;
            this.usun.Text = "usun";
            this.usun.UseVisualStyleBackColor = true;
            this.usun.Click += new System.EventHandler(this.usun_Click);
            // 
            // sortuj
            // 
            this.sortuj.Location = new System.Drawing.Point(691, 318);
            this.sortuj.Name = "sortuj";
            this.sortuj.Size = new System.Drawing.Size(83, 108);
            this.sortuj.TabIndex = 2;
            this.sortuj.Text = "sortuj";
            this.sortuj.UseVisualStyleBackColor = true;
            this.sortuj.Click += new System.EventHandler(this.sortuj_Click);
            // 
            // tabela
            // 
            this.tabela.AllowUserToAddRows = false;
            this.tabela.AllowUserToDeleteRows = false;
            this.tabela.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabela.Location = new System.Drawing.Point(16, 88);
            this.tabela.MultiSelect = false;
            this.tabela.Name = "tabela";
            this.tabela.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.tabela.Size = new System.Drawing.Size(669, 350);
            this.tabela.TabIndex = 3;
            // 
            // dodajImie
            // 
            this.dodajImie.Location = new System.Drawing.Point(73, 36);
            this.dodajImie.MaxLength = 45;
            this.dodajImie.Name = "dodajImie";
            this.dodajImie.Size = new System.Drawing.Size(100, 20);
            this.dodajImie.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 39);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(25, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "imie";
            // 
            // dodajNazwisko
            // 
            this.dodajNazwisko.Location = new System.Drawing.Point(73, 62);
            this.dodajNazwisko.MaxLength = 45;
            this.dodajNazwisko.Name = "dodajNazwisko";
            this.dodajNazwisko.Size = new System.Drawing.Size(100, 20);
            this.dodajNazwisko.TabIndex = 9;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 65);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(54, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "nazwisko ";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.dodajNazwisko);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.dodajImie);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tabela);
            this.Controls.Add(this.sortuj);
            this.Controls.Add(this.usun);
            this.Controls.Add(this.dodaj);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.tabela)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button dodaj;
        private System.Windows.Forms.Button usun;
        private System.Windows.Forms.Button sortuj;
        private System.Windows.Forms.DataGridView tabela;
        private System.Windows.Forms.TextBox dodajImie;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox dodajNazwisko;
        private System.Windows.Forms.Label label3;
    }
}

