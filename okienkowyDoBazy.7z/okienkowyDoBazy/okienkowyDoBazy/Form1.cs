﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace okienkowyDoBazy
{
    public partial class Form1 : Form
    {
        private static string connectionString = "datasource=127.0.0.1;port=3306;username=root;password=;database=test;";
        private MySqlConnection databaseConnection = new MySqlConnection(connectionString);

        public Form1()
        {
            InitializeComponent();
            WyswietlTabele(string.Empty);
        }

        private void dodaj_Click(object sender, EventArgs e)
        {
            string dodImie = dodajImie.Text;
            string dodNazwisko = dodajNazwisko.Text;
            if (string.IsNullOrEmpty(dodImie) || string.IsNullOrEmpty(dodNazwisko))
            {
                MessageBox.Show("Nie podałeś wszystkich wymaganych danych.", "Błąd zapisu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (dodImie.Length > 45 || dodNazwisko.Length > 45)
            {
                MessageBox.Show("Podane dane są za długie.", "Błąd zapisu", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            string query = $"INSERT INTO users (name, last_name) VALUES ('{dodImie}','{dodNazwisko}');";
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;

            try
            {
                databaseConnection.Open();
                commandDatabase.ExecuteReader();
                MessageBox.Show("Udało się, normalnie cud!");
                databaseConnection.Close();
                dodajImie.Text = string.Empty;
                dodajNazwisko.Text = string.Empty;
                WyswietlTabele(string.Empty);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void usun_Click(object sender, EventArgs e)
        {
            if (tabela.Rows.Count == 0 || tabela.SelectedRows.Count == 0)
            {
                MessageBox.Show("Nie ma co usuwać, odczep się!");
                return;
            }

            int doUsuniecia = tabela.SelectedRows[0].Index;
            int id = int.Parse(tabela.Rows[doUsuniecia].Cells[0].Value.ToString());
            string query = $"DELETE FROM users WHERE Id_user = {id};";
            MySqlCommand commandDatabase = new MySqlCommand(query, databaseConnection);
            commandDatabase.CommandTimeout = 60;

            try
            {
                databaseConnection.Open();
                commandDatabase.ExecuteReader();
                MessageBox.Show("Udało się, normalnie cud!");
                databaseConnection.Close();
                WyswietlTabele(string.Empty);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void sortuj_Click(object sender, EventArgs e)
        {
            string doczepka = "ORDER BY users.name ASC, users.last_name ASC";
            WyswietlTabele(doczepka); 
        }

        private void WyswietlTabele(string doczepka)
        {
            try
            {
                DataTable dt = new DataTable();
                string query = $"SELECT * FROM users {doczepka};";
                MySqlDataAdapter adapter = new MySqlDataAdapter(query, databaseConnection);
                databaseConnection.Open();

                adapter.Fill(dt);
                tabela.DataSource = dt;
                tabela.AutoResizeColumns();

                databaseConnection.Close();
                tabela.Refresh();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
